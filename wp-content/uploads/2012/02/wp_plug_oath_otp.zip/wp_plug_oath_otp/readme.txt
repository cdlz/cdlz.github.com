﻿=== OATH ===
Contributors: imzc
Donate link: http://imzc.net/wp_otp/
Tags: captcha,OTP
Requires at least: 2.9
Tested up to: 3.3
Stable tag: 2.21

This plugin allows you to implement super security captcha form into web forms.

== Description ==
 OATH_OTP,for One-Time Password , ios dynamic code authen.