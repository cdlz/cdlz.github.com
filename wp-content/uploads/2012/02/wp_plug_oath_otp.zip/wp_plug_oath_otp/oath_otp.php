<?php
 /*
 Plugin Name: OATH_OTP
 Plugin URI: http://imzc.net/wp_otp/
 Version: 0.0.1
 Author: Richard Chou
 Description: OATH_OTP
 */
 
 @error_reporting(0);  
 
global $shakehand_key;
 
//20bit
$shakehand_key = get_option("shakehand_key");
  /*
function print_bottom_info($echo = true){
	$bottem_string  = '<div class="bottominfo">';
	$bottem_string .= '<p>作者：<a href="' . get_the_author_url() . '">' . get_the_author() . '</a></p>';
	$bottem_string .= '<p>原文链接：<a href="' . get_permalink(get_the_ID()) . '">' . get_the_title() . '</a></p>';
	$bottem_string .= '<p><a href="' . get_bloginfo('siteurl') . '">《' . get_bloginfo('name') . '》</a>版权所有，转载时必须以链接形式注明作者和原始出处及本声明。</p>';
	$bottem_string .= '</div>';
	if ($echo)
	{
		echo $bottem_string;
		return;
	}
	else
	{
		return $bottem_string;
	}
}

function add_info($content = '')
{
	if(is_single())
	{
		$content .= print_bottom_info(false);
	}
	return $content;
}



	add_filter('the_content','add_info',1,1000);
	
*/

//translate language, not completed.
if(!function_exists('tr')){
	function tr($str ,$section){
		//$language  =array(  );
		return $str ;
	}
}


function auth_check($clientSideSha1Str){
	global $shakehand_key;
	//die($shakehand_key);
	$seed = time();
	$seed = $seed - $seed%30 ;
	//$clientSideSha1Str = sha1($code.$shakehand_key);
	$webSideSha1Str =sha1($seed.$shakehand_key);
	//echo "====seed:$seed=====".$webSideSha1Str.",".$clientSideSha1Str."===";
	
	$clientSideCode = substr($clientSideSha1Str,0,6);
	$webSideCode = substr($webSideSha1Str,0,6);
	
	if($clientSideCode == $webSideCode ){
		return true;
	}else{
		return false;
	}
}
// this function adds captcha to the login form
function oath_login_form() {
	if( session_id() == "" )
		session_start();
	global $cptch_options;
	
	// captcha html - login form
	echo '<p class="cptch_block">';
	if( "" != $cptch_options['cptch_label_form'] )	
		echo '<label>'. stripslashes( $cptch_options['cptch_label_form'] ) .'</label><br />';
	if( isset( $_SESSION['cptch_error'] ) ) {
		echo "<br /><span style='color:red'>". $_SESSION['cptch_error'] ."</span><br />";
		unset( $_SESSION['cptch_error'] );
	}
	echo '<br />';
	oath_display_captcha();
	echo '</p>
	<br />';

	return true;

} //  end function oath_login_form

// this function checks captcha posted with a login
function oath_login_post($errors) {
	global $str_key;
	$str_key = "123";
	// Delete errors, if they set
	if( isset( $_SESSION['cptch_error'] ) )
		unset( $_SESSION['cptch_error'] );

	if( isset( $_REQUEST['action'] ) && 'register' == $_REQUEST['action'] )
		return($errors);

	// If captcha not complete, return error
	if ( isset( $_REQUEST['cptch_number'] ) && "" ==  $_REQUEST['cptch_number'] ) {	
		return $errors.'<strong>'. tr( 'ERROR', 'captcha' ) .'</strong>: '. tr( 'Please complete the CAPTCHA.', 'captcha' );
	}

	//if ( isset( $_REQUEST['cptch_result'] ) && isset( $_REQUEST['cptch_number'] ) && 0 == strcasecmp( trim( decode( $_REQUEST['cptch_result'], $str_key ) ), $_REQUEST['cptch_number'] ) ) {
	if(auth_check(trim($_REQUEST['cptch_number']))===true){
		// captcha was matched						
	} else {
		return $errors.'<strong>'. tr( 'ERROR', 'captcha' ) .'</strong>: '. tr( 'That CAPTCHA was incorrect.', 'captcha' );
	}
  return($errors);
} // end function oath_login_post

// this function checks the captcha posted with a login when login errors are absent
function oath_login_check($url) {
	global $str_key;
	global $auth_tmp_key;
	if( session_id() == "" )
		session_start();

	$str_key = "123";
	// Add error if captcha is empty
	if ( isset( $_REQUEST['cptch_number'] ) && "" ==  $_REQUEST['cptch_number'] ) {
		$_SESSION['cptch_error'] = tr( 'Please complete the CAPTCHA.', 'captcha' );
		// Redirect to wp-login.php
		return $_SERVER["REQUEST_URI"];
	}
	if ( isset( $_REQUEST['cptch_result'] ) && isset( $_REQUEST['cptch_number'] ) ) {
		//if ( 0 == strcasecmp( trim( decode( $_REQUEST['cptch_result'], $str_key ) ), $_REQUEST['cptch_number'] ) ) {
		//echo "===".$_REQUEST['cptch_number']."<>==".$auth_tmp_key."==";
	//	if ( 0 == strcasecmp( trim($_REQUEST['cptch_number'] ), $auth_tmp_key) ) {
		if(auth_check(trim($_REQUEST['cptch_number']))===true){
			return $url;		// captcha was matched						
		} else {
			// Add error if captcha is incorrect
			$_SESSION['cptch_error'] = tr('That CAPTCHA was incorrect.', 'captcha');
			// Redirect to wp-login.php
			return $_SERVER["REQUEST_URI"];
		}
	}
	else {
		return $url;		// captcha was matched						
	}
} // end function oath_login_post



// Functionality of the captcha logic work
function oath_display_captcha()
{
	global $cptch_options,$auth_tmp_key ;
    global $shakehand_key;
	
	// String for display 
	$seed = time();
?>
    OATH_OTP(<?php echo substr("$seed",-3,3);?>):<input type="text" name="cptch_number" tabindex="30" value="" maxlength="10" size="1" style="width:100px;margin-bottom:0;display:inline;" /><br /><?php
	
	
//	$seed = $seed - $seed%30 ;
//	$clientSideSha1Str = sha1($seed.$shakehand_key); 
	
//	echo $clientSideCode = substr($clientSideSha1Str,0,6);
//	echo sha1("test"); 
//echo "<br />".$seed."<br />";
	   ?>
	<input type="hidden" name="cptch_result" value=" <?php echo $auth_tmp_key; ?>" /><input type="hidden" value="Version: 0.0.1" />
	 
<?php
}
 


	//在这里正式hook到WP内部
	
	add_action( 'login_form', 'oath_login_form' );
	add_filter( 'login_errors', 'oath_login_post' );
	add_filter( 'login_redirect', 'oath_login_check', 10, 3 ); 

 
 
 
  
  
// Function for display oather settings page in the admin area

function oather_activate() {
    add_option( 'shakehand_key',  "testcoco" );
    //这里也可以用update_option，区别是使用update_action会在每一次重新启用插件时重置用户设置为默认值。
	 
}
register_activation_hook(__FILE__, 'oather_activate');


function oather_admin_init(){
    //注册配置，第3个参数是回调函数，用于过滤提交的内容
	//register_setting( $option_group, $option_name, $sanitize_callback )
    register_setting( 'shakehand_key', 'oather_options', 'oather_options_validate' );
	
	 //添加设置群
	 //add_settings_section( $id, $title, $callback, $page ); 
    add_settings_section('oather_main', tr('Settings','oath'), 'oather_section', 'oather');
   
   //添加具体配置
    //add_settings_field( $id,                  $title,                               $callback,    $page,      $section,   $args );
    add_settings_field('oather_shakehand_key', tr('oather_shakehand_key','oath'), 'oather_authkey', 'oather', 'oather_main'); 
    
	 
}
add_action('admin_init', 'oather_admin_init');



function oather_authkey()
{
    $shakehand_key = get_option( 'shakehand_key' ); 
//	echo "<br> $shakehand_key:";print_r($shakehand_key);
?><input id="oather_shakehand_key" name="oather_shakehand_key" style="width:200px;" maxlength="20"  value="<?php echo $shakehand_key;?>" />(6-20 chars,and use olny a-zA-Z0-9)<br />
<?php
}



function oather_section($section){
	return $section;//echo "<br>oather_section:";print_r($section);
}
function oather_options_validate($input) {
	// echo "<br>oather_options_validate:";print_r($input);
    //$input['oather_shakehand_key'] = $input['oather_shakehand_key'] ? $input['oather_shakehand_key'] : "inittestcoco"; 
    return $input;
}

function oather_options_page() {
?>
    <div class="wrap">
        <h2><?php echo tr('OATH_OTP','oath'); ?></h2>
        <div class="narrow">
             <script language="javascript">
             function check_shakehand_key(){
			     var shankhand = document.getElementById("oather_shakehand_key") ;
				 if(!/^[A-Za-z0-9]{6,20}$/.test(shankhand.value)){ 
				   alert('Shakehand key  must use only with 6-20 chars(a-zA-Z0-9).');
				   return false;
				 }
				 
				 return true;
			}
             </script>
            <form action="options.php" method="post" >
                <p>Features include:<br> 
-Support for multiple wordpress blogs on our ios app. <br>  
-Support for time-based code generation only in this version. </p>
                <?php settings_fields('shakehand_key'); ?>
                <?php do_settings_sections('oather'); ?>
                <p class="submit">
                    <input name="submit" type="submit" class="button-primary" onclick="return check_shakehand_key()" value="<?php echo tr('Save Changes','oath') ?>" />
                </p>
            </form>
        </div>
    </div>
<?php
}


 //在设置页添加链接
function oather_menu() {
    add_options_page('OATH_OTP Settings',  tr('OATH_OTP','oath'), 'manage_options', 'oath_otp', 'oather_options_page');
}

function oather_action_links( $links, $file ) {
    if ( $file != plugin_basename( __FILE__ ))
        return $links;
    $settings_link = '<a href="options-general.php?page=oath_otp">Settings</a>';
    array_unshift( $links, $settings_link );
    return $links;
    //在插件页添加链接
}
add_filter( 'plugin_action_links', 'oather_action_links',10,2);
add_action('admin_menu','oather_menu');


/*if ( isset($_GET['update']) ) {
	$messages = array();
		switch ( $_GET['settings-updated'] ) { 
			case "false":
				$messages = __('Shakehand key  must use only with 6-20 chars(a-zA-Z0-9).');
				break;
			case "true":
				$messages = __('Options saved.');
				break;
		}
}
*/

if(isset($_POST['oather_shakehand_key'])){
	//update post
	
	    $shakehand_len = strlen($_POST['oather_shakehand_key']);
		if($shakehand_len >=6  && $shakehand_len <=20){ 
               //  print_r($_POST);    
		 	   update_option( 'shakehand_key', $_POST['oather_shakehand_key'] ,'', 'yes' );
	           $redirect = add_query_arg( array('settings-updated' => 'true'), 'options-general.php' ); 
				$messages = __('Options saved.');
		}else{
			   $redirect = add_query_arg( array('settings-updated' => 'false'), 'options-general.php' ); 
				$messages = __('Shakehand key  must use only with 6-20 chars(a-zA-Z0-9).');
		 }
	 
			 
			// echo $messages;
	
}
  
 

 ?>