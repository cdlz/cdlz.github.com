/*
  ����ls -R,�ݹ�Ŀ¼�г�����Ϣ��ʽ����Ҫȫ·��ʱ���ô���,���ר��д��һ����.
  linux�±���:  gcc lsdir.c -o lsdir -O
  windows�±���:ʹ��codeblocks����.
  Useage: lsdir
	 list the full path of a dir's subdirs or files,not same as  "ls -R".
	 -h,    print this message.
	 -d dirname,    recursely print full path of files.
	 -D,    print dirs only.
	 -F,    print files only.
	 -A,    print files and dirs(defult).
	 -R,    print dir recurse(defult).
	 -r,    only print current dir.
	 none argvs,    print current path.
									---zhouchuan,2010.8.27.
*/
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#ifdef __WIN32__  // OS_COMPAT
//__WINDOWS__
 char path_sep = '\\';
#else
 char path_sep = '/';
#endif   // !__WINDOWS__

#define DIR_MAX_LEN 1000
#define PRINT_DIR_ONLY 0
#define PRINT_FILE_ONLY 1
#define PRINT_FILE_AND_DIR 2

#define DIR_RECURSE_NO 0
#define DIR_RECURSE_YES  1

int g_PRINT_TYPE = PRINT_FILE_AND_DIR; //Ĭ���г�����Ŀ¼���ļ�
int g_DIR_RECURSE = DIR_RECURSE_YES;//Ĭ�ϵݹ�

void printdir(char *dir, int depth)
{
	DIR *dp;
	struct dirent *entry;
	struct stat statbuf;
	char  buff[DIR_MAX_LEN];


		    if((dp = opendir(dir)) == NULL) {
			      fprintf(stderr, "cannot open directory: %s\n ", dir);
			         return;
		     }
		     chdir(dir);
             getcwd(buff,DIR_MAX_LEN);
		     while((entry = readdir(dp)) != NULL) {
		         //lstat(entry-> d_name,&statbuf);
		        stat(entry-> d_name,&statbuf);
		        if(S_ISDIR(statbuf.st_mode)) {
                       /* Found a directory, but ignore . and .. */
                   if(strcmp( ".",entry-> d_name) == 0 ||strcmp( "..",entry-> d_name) == 0)
                      continue;
                  // printf( "%*s%s/\n ",depth, " ",entry-> d_name);
                    if(g_PRINT_TYPE != PRINT_FILE_ONLY)
                        printf( "%s%c%s%c\n ",buff,path_sep,entry-> d_name,path_sep);

                     /* Recurse at a new indent level */
                     if(g_DIR_RECURSE==DIR_RECURSE_YES)
                        printdir(entry-> d_name,depth+4);
 			    }else{
                    //is a file
                    if(g_PRINT_TYPE !=PRINT_DIR_ONLY){
                        printf( "%s%c%s\n ",buff,path_sep,entry-> d_name);
                    }
			   }
			}
			chdir( "..");
			closedir(dp);
}

void useage(){
   printf("====================================================================\n");
   printf("Useage: lsdir\n");
   printf(" list the full path of a dir's subdirs or files,not same as  \"ls -R\". \n");
   printf(" -h,\tprint this message.\n");
   printf(" -d dirname,\trecursely print full path of files. \n");
   printf(" -D,\tprint dirs only. \n");
   printf(" -F,\tprint files only. \n");
   printf(" -A,\tprint files and dirs(defult). \n");
   printf(" -R,\tprint dir recurse(defult). \n");
   printf(" -r,\tonly print current dir. \n");
   printf(" none argvs,\tprint current path.\n");
   printf("\t\t\t\t---zhouchuan,2010.8.27.\n");
   printf("====================================================================\n");
}

int main(int argc, char* argv[])
{
     int oc;                     /*ѡ���ַ� */
     char *b_opt_arg;            /*ѡ������ִ� */
     char *topdir=NULL, pwd[2]= ".";

        while((oc = getopt(argc, argv, "hd:DFARr")) != -1)
        {
            switch(oc)
            {
                case 'h':
                   //-h,���ӡʹ�÷���
                    useage();
                    return 0;
                    break;
                case 'D':
                    g_PRINT_TYPE =PRINT_DIR_ONLY ;
                    break ;
                case 'F':
                    g_PRINT_TYPE =PRINT_FILE_ONLY ;
                    break ;
                case 'A':
                    g_PRINT_TYPE =PRINT_FILE_AND_DIR ;
                    break ;
                case 'R':
                      g_DIR_RECURSE = DIR_RECURSE_YES;
                //       printf(" DIR_RECURSE_YES");
                      break;
                case 'r':
                      g_DIR_RECURSE = DIR_RECURSE_NO;
                   //    printf(" DIR_RECURSE_NO");
                      break;
                case 'd':
                    b_opt_arg = optarg;
              //      printf("dir %s\n", optarg);
                    topdir=optarg;
                    break;
            }
        }
   if(topdir==NULL)
   {
     //   printf("dir current");
        topdir=pwd;
    }
	    printf("Directory scan of \"%s\":\n ",topdir);
	    printdir(topdir,0);
	    printf("===Done.\n ");

	   return 0;
}
