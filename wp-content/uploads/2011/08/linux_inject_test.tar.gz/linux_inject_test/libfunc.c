#include<stdio.h> 

int o_lib_function (char * msg){ 
        if(NULL==msg)
	{
		printf("Null chars,exit. \n");
		return -1;
	}
	printf("In lib test,hello,world to %s .\n",msg);
	return 1;
}
