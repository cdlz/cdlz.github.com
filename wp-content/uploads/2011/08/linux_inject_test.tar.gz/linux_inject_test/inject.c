#include<stdio.h>
#include<dlfcn.h>

int o_lib_function (char * msg){
	void * hl = dlopen("/lib/libfunc.so",RTLD_NOW|RTLD_GLOBAL);
	typedef int (*f) (char * );
	f old_lib_function = (f) dlsym(hl, "o_lib_function");
	printf("call in injected function. \n");
	return (* old_lib_function)(msg);
}
