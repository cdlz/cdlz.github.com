/*
1. sudo -s -H
2. export LD_LIBRARY_PATH=/pwd_dirname/:$LD_LIBRARY_PATH 

3.makefile:

CC=gcc
OBJS=libfunc.so libinject.so  main 

all: $(OBJS)

libfunc.so:libfunc.c
	$(CC) -o libfunc.so  libfunc.c -shared -Wall
	cp libfunc.so /lib/libfunc.so

libinject.so:inject.c
	$(CC) -o libinject.so inject.c -ldl -shared -Wall
	cp libinject.so libfunc.so

main:main.c
	$(CC) -o main  main.c   libfunc.so -Wall
 
	
clean:
	rm -f $(OBJS)  /lib/libfunc.so
*/
#include<stdio.h>

int o_lib_function(char *);

int main (int argc,char ** argv){
	if(argc<=1){
		printf("usage: main helloname \n");
 		return -1;
	}
	o_lib_function(argv[1]);
	return 1;
}
