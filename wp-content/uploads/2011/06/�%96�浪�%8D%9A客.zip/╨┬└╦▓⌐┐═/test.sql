/*
Navicat MySQL Data Transfer
Source Host     : localhost:3306
Source Database : test
Target Host     : localhost:3306
Target Database : test
Date: 2011-06-19 23:37:20
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for posts
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `content` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES ('1', 'mysql odbc', '13 April 2011 - Individuals recently claimed to have hacked portions of the MySQL.com and Sun.com web sites. The results of Oracle\'s preliminary investigation do not indicate a wide compromise; however the attackers published a small number of user IDs, e-mails, and passwords. In an abundance of caution, Oracle recommends that users who had accounts on these systems change their passwords as soon as possible. Furthermore, users who employed the same passwords on other systems should change them as well. Guidelines for choosing strong passwords are readily available on the Internet, including on Wikipedia (http://en.wikipedia.org/wiki/Password_strength).');
INSERT INTO `posts` VALUES ('2', '汇编转机器码,嵌入目标进程', '实际上可以用到很多语言中, 实现非常简单, 大家可以看看标准库中提供的源码.\r\n目前AAuto已可支持C语言、汇编语言、Javascript语言、PHP语言等。AAuto开发速度很快、写扩展库更快。\r\n\r\nAAuto可以轻松写入机器码到指定进程.\r\n并转换为普通的AAuto函数.\r\n\r\n下面是一个范例,使用上面提到的工具生成机器码写入到当前进程.\r\n然后转换为普通函数getCpuId(), 然后调用该函数获取CPU信息.\r\n\r\nimport process\r\n\r\n//打开目标进程，可在参数中指定程序路径\r\nvar prcs = process();\r\n\r\n//机器码\r\nvar bin = \'\\x55\\x89\\xE5\\x81\r\n\\xEC\\xC0\\x00\\x00\r\n\\x00\\x53\\x56\\x57\r\n\\x8B\\x75\\x08\\x31\r\n\\xC0\\x0F\\xA2\\x89\r\n\\x1E\\x89\\x56\\x04\r\n\\x89\\x4E\\x08\\x5F\r\n\\x5E\\x5B\\x89\\xEC\r\n\\x5D\\xC3\'\r\n\r\n//写入机器码\r\nvar pfun = prcs.malloc(#bin);\r\nprcs.writeString(pfun,bin )\r\n\r\n//创建函数对象\r\ngetCpuId = prcs.remoteApi(\"void(struct &cpuid)\",pfun,\"cdcel\" ) \r\n\r\n//调用函数\r\nvar cpuid = getCpuId( { BYTE name[20] } )\r\n\r\n//输出结果\r\nio.open()\r\nio.print( cpuid.name )\r\n\r\n//释放内存\r\nprcs.mfree(pfun);\r\n');
INSERT INTO `posts` VALUES ('3', 'php', '解析PHP文件，捕获输出\r\n\r\n  \r\nimport php;\r\n\r\n//指定PHP输出函数\r\nphp.print = function( msg ) {\r\n    io.print(\"PHP输出内容:\", msg) \r\n}\r\n\r\n//生测测试的PHP文件\r\nphpcode = /*\r\n<?php \r\n    echo \"<p>Hello World</p>\";  \r\n?>\r\n*/\r\n\r\nio.open()\r\nstring.save(\"/test.php\",phpcode )\r\nphp.dofile(\"/test.php\")\r\n\r\n//直接写 php.exec( phpcode ) 也可以\r\nphp.exec( phpcode )');
INSERT INTO `posts` VALUES ('4', 'php 2', '在PHP中自由调用AAuto语言\r\n\r\nimport php;\r\n\r\n//打开控制台\r\nio.open() ;\r\n\r\n//PHP代码\r\nphpcode =/* \r\n    $ret = aauto(\"\r\n        import win;\r\n        win.msgbox(\'我是aauto代码\');\r\n        return 123;\r\n    \")\r\n*/ \r\n\r\n//运行PHP代码,返回表达式的值\r\nvar ret = php.eval(phpcode) \r\nio.print( ret );');
INSERT INTO `posts` VALUES ('5', 'php3', 'AAuto调用PHP代码演示\r\n\r\n  \r\nimport php;\r\n\r\n//PHP代码\r\nphpcode =/* \r\n    echo \"Hello,我是PHP\";\r\n    $abc = 123;\r\n*/ \r\n\r\n//运行PHP代码,返回表达式的值\r\nphp.exec(phpcode) \r\n\r\nio.open()\r\nio.print( php.abc ) //取php变量\r\n\r\n\r\n上面的方法实际上可以用到很多语言中, 实现非常简单, 大家可以看看标准库中提供的源码.\r\n目前AAuto已可支持C语言、汇编语言、Javascript语言、PHP语言等。AAuto开发速度很快、写扩展库更快。');
